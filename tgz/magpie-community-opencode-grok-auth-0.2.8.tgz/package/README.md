# @magpie-community/opencode-grok-auth

Grok with a SuperGrok or X Premium+ subscription, through the sign-in of
xAI's [Grok Build CLI](https://x.ai/cli). Provider id: `grok`.

It needs Grok Build installed:

```sh
curl -fsSL https://x.ai/cli/install.sh | bash          # macOS, Linux
irm https://x.ai/cli/install.ps1 | iex                 # Windows
```

It is found in the installer's folder (`GROK_BIN_DIR`, `GROK_HOME/bin`,
`~/.grok/bin`), or on `PATH` when it lives under a `.grok` folder, so that
another program named `grok` isn't taken for it. Where the installer can't
run, such as a container without curl, put the binary in a folder of your
own and set `GROK_BIN_DIR` to it. magpie installs Grok Build itself, as
the installer does, before a sign-in that needs it.

## Images and speech

Images in a request (Anthropic image blocks, OpenAI `image_url`, Responses
`input_image`) go to Grok as sent, and its models take them. Speech to text
is the one Grok Build's voice dictation uses: magpie's
`/v1/audio/transcriptions` (model `grok/grok-4.7`, any of the account's
models) is sent on to xAI's `api.x.ai/v1/stt` with the account's sign-in.
`language` is passed on; `json`, `text` and `verbose_json` are answered, and
translations are refused.

## Sign in

- **Sign in with Grok Build (device code)** runs `grok login --device-auth`
  and opens the page it prints. Approve the sign-in there, and the CLI
  finishes it.
  - If the CLI isn't signed in yet, the sign-in goes to the CLI's own home
    (`GROK_HOME`, else `~/.grok`), as if you had run `grok login`.
  - If it is signed in, the sign-in goes to a home of this plugin's,
    `$XDG_CONFIG_HOME/opencode-grok-auth/<random>` (else under
    `~/.config`). Grok Build's own sign-in stays as it is.
  - The account is told apart by its email, else its xAI user id (an
    account signed in through X can have no email). `GROK_AUTH_PATH` is
    left out of the CLI's run, so the sign-in lands in that home.
  - When the CLI finishes but leaves no sign-in there, the failure says
    which file it read and what it found.
  - The plugin waits 30 seconds for a link and up to 10 minutes for the
    interaction, including its callback. The latter is a local wait limit,
    not xAI's device-code expiry: the CLI owns that expiry and doesn't
    expose it with the printed link. Cancel or start again if needed.
    Cancellation, failure or timeout stops the CLI and removes only a new,
    unsaved private home. The CLI's existing home is left in place, and a
    successful account's home is kept, including on repeated callbacks.
- **Use Grok Build's current sign-in** takes the account the CLI is
  signed in to, with nothing to approve.
- **Import CPA / sub2api Grok account JSON** accepts a file path or pasted
  JSON for one account. CPA's enabled xAI OAuth account files
  (`~/.cli-proxy-api/xai-<email>.json`) remain supported. sub2api accounts
  must explicitly name `platform: "grok"` and `type: "oauth"`, with their
  OAuth fields under `credentials`; `expires_at` is an RFC3339 string,
  not Unix seconds. An X sign-in can omit email when its user id or token
  subject identifies the account.
  - In magpie, **Import accounts from a file…** accepts multiple JSON files
    or pasted JSON: individual accounts, lists, or sub2api exports with an
    `accounts` list (`type: "sub2api-data"`, `version: 1`, when present).
    Other platforms and non-OAuth accounts are skipped; malformed Grok
    credentials report an error. The single-account method directs exports
    containing several Grok accounts to this bulk import.
  - Imports require the Grok Build xAI client
    (`b1a00492-073a-47ea-816f-4c329264a828`) and its token issuer/audience.
    sub2api can configure another client id; those accounts can't be
    imported for this CLI. Grok Build remains responsible for renewal.
  - Duplicate accounts make one home. Existing private or CLI sign-ins are
    reused without rewriting them. Cancelling a bulk import removes all
    homes that batch created before returning its accounts.
  - Stop using the imported accounts in CPA or sub2api before continuing:
    both clients rotate the same refresh token, so they must not refresh
    the account concurrently. Import reads the source without changing its
    files, disabling accounts or contacting xAI.

## Where the sign-in is kept

The CLI keeps the sign-in in its home, as `auth.json`. OpenCode (or
magpie) keeps where that home is, the token and its expiry. Importing a CPA
or sub2api account writes only its translated xAI OAuth fields to a private
home owned by this plugin; source files are left unchanged.

The plugin reads `auth.json`; Grok Build refreshes the token, which changes
each time. The plugin runs `grok models` in that home, so the CLI renews
it, then reads it again:

- magpie renews the token 5 minutes before it ends, through the plugin's
  `auth.refresh`, once for the account and before its requests, models
  and usage need it. magpie saves what the CLI gave.
- OpenCode doesn't call that hook: there the token is renewed when it is
  5 minutes from expiring, before a request.
- The CLI runs once for a home at a time: a request or renewal that
  comes while it runs waits for it and reads what it gave. A token the
  CLI already renewed is taken as it is.
- Grok can turn a token away before its `expires_at`. A request, model
  list or usage read that gets 401 has the CLI renew the token and asks
  once more with the new one.
- When the CLI's run leaves the token as it was, the 401 or error says
  Grok Build couldn't renew the sign-in, with what the CLI said. For Grok
  Build's own home ("Use Grok Build's current sign-in") opening Grok Build
  and sending it a message renews it. For a home of the plugin's (a second
  account, an imported one), opening Grok Build doesn't touch it: add the
  account in magpie again.
- Not every 401 is Grok judging the token. A token it doesn't take is
  answered at once with `Invalid or expired credentials (…)`. Another
  401, such as `Authentication required` after a minute or more, on a
  token the CLI left as it was and not yet ended, has passed by itself
  within minutes. Unless the CLI failed renewing it, that is a 503 with
  `Retry-After: 60` that keeps the sign-in and says how long Grok took:
  magpie rests the account a moment and asks the next one. It never says
  to sign in again.
- A request, model list or usage read turned away waits on the CLI's
  renewal 15 seconds at most. The run goes on, and the next one to ask
  takes what it gave.
- When the CLI no longer holds a sign-in in that home (`grok logout`),
  the account has to be signed in again. When it couldn't renew a token
  that has ended, magpie tries again later.
- An `auth.json` that is empty or not JSON is most likely one the CLI is
  writing: it is read again for about half a second, then the last sign-in
  read whole there stands, as the CLI itself keeps its previous one. It is
  never taken as signed out. The plugin takes no `auth.json.lock`.

## Requests

Requests go to `https://cli-chat-proxy.grok.com/v1`, OpenAI's Responses
API (`@ai-sdk/openai`), signed as the CLI signs them:

- `Authorization: Bearer <token>`
- `x-xai-token-auth: xai-grok-cli`
- `x-grok-client-identifier: grok-shell`
- `x-grok-client-mode: headless`
- `x-grok-client-version` and `User-Agent: grok-shell/<version> (<os>; <arch>)`.
  The version is 1.0.41, or the installed CLI's if it is newer.
- `x-grok-model-override`: the request's model. A window suffix
  (`grok-4.7@500k`) is the plain model (`grok-4.7`) here and in the body.
- `x-grok-context-window`: the token count a suffixed model names
  (`500000` for `@500k`). The plain id sends no such header and stays on
  the default window.
- `x-grok-conv-id`: the request's `prompt_cache_key`.
- `x-grok-doom-loop-check: 1024` and `x-grok-exact-repetition-check: 64`
  on a Responses request, as Grok Build sends them: the proxy then stops a
  reply that repeats itself after ~1K tokens instead of letting it run on.
- A Responses stream that dies before its first byte (the connection
  reset, with nothing sent yet) is asked again, up to three times. The
  retry goes out before the answer is returned, so a 429 or a 401 comes
  back as itself. Once a byte has arrived, `response.created` and
  reasoning included, it is passed on at once. A later cut is not asked
  again and not rewritten: the stream ends, and magpie 0.1.3298 or newer
  closes it as `response.failed` with `created_at` and `sequence_number`.
  The frame this plugin used to write had `created_at` and still no
  `sequence_number`, so Grok Build reported
  `missing field sequence_number`. An upstream `response.failed`,
  `error` or `response.incomplete` is passed on unchanged. Cancelling
  the turn stops the read and is not asked again.

The backend turns away some of what a request may carry, so the plugin
leaves these out:

- tools of types it doesn't take (a freeform `apply_patch`, namespaces)
- `external_web_access` on web search
- a `tool_choice` naming a dropped type
- a `tool_choice` with no tools beside it (magpie sends `"none"` so when a
  client turned tools off)
- a reasoning item's `"content": null`

Plain Codex collaboration items (`agent_message`) reach Grok as user
messages, with their sender, recipient and content preserved. Sealed or
unrecognized content stays unchanged; the plugin does not decrypt tasks.

### Native X search (optional)

In magpie, open the Grok provider, turn on **Native X search** under
**Plugin options**, and save. It is off by default; changes apply to the
next request without restarting or signing in again.

When enabled, the plugin offers Grok its native `x_search` tool. Grok
decides whether to search; enabling it does not force a search on every
request. Existing function tools and X search filters are preserved, and
an existing `x_search` is not duplicated. Explicit choices such as `none`,
`required`, a named tool, or `allowed_tools` never gain another tool.

The option applies to Responses requests, including Chat Completions,
Anthropic Messages and Gemini requests that magpie converts to Responses,
in streaming and non-streaming mode. Use magpie with the fix for
[yetone/magpie#3110](https://github.com/yetone/magpie/issues/3110) so that
those clients' tool-disable choices reach the plugin.

For compatibility with older gateways, a request that reaches the plugin
with neither tools nor a `tool_choice` is left unchanged. This can happen
when magpie translates a client's automatic choice on an empty tool list.
To use X search through a translated API, send at least one function tool;
the plugin adds X search alongside it. An explicit tool-disable choice
always takes precedence.

This uses the existing `grok` provider's login, models and quota reporting;
no extra plugin is needed. It applies to that provider's models when the
upstream supports X search, not to Grok models served through Cursor or
another provider. Report problems in
[this repository](https://github.com/magpie-community/plugins/issues).

## Models

Grok 4.7 until signed in. Signed in, the models are the ones the account
lists at `/v1/models` (Responses models only), each with its reasoning
efforts as variants.

`context_window` is the default window and keeps the plain id, so a saved
`grok-4.7` stays a 256k model. Each other size in `context_windows` is
offered beside it, named `Grok 4.7 @ 500k` with id `grok-4.7@500k` and
that many tokens as its window. A request for it sends
`x-grok-context-window: 500000`. The proxy serves up to its largest
window either way and refuses past it; the header names the window the
caller asked to compact against. Pick `grok-4.7@500k` where a client
compacts at the advertised window, such as Claude Code.

## Usage

magpie's card shows the credits of the current period
(`/v1/billing?format=credits`): weekly for SuperGrok, with on-demand
spending beside it when it has a cap.

Grok's billing says nothing of a plan's rate limit, so a free account can
read 0% used while its requests come back 429. After a 429 the card shows
a spent "Rate limit" window until the reset it named (`Retry-After`, or a
`*ratelimit*reset*` header). When it named none, the window stays until a
request goes through, or for 5 minutes.

Grok Bot's separate allowance is shown by the [Cursor plugin](../cursor/README.md#usage).
Sign in there with the Cursor account linked in Grok Bot, including for
access through SuperGrok.
