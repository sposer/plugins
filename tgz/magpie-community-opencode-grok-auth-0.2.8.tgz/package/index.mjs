// Grok (SuperGrok / X Premium+) through the Grok Build CLI's own sign-in.
//
// The CLI (https://x.ai/cli) signs in with a device code and keeps the
// sign-in in its home (GROK_HOME, else ~/.grok) as auth.json. This plugin
// only reads that file: the CLI refreshes the token, which changes each
// time, so a token about to expire is renewed by running the CLI there
// (`grok models`), never by the plugin itself. Requests go to the CLI's
// backend, which speaks OpenAI's Responses API, signed as the CLI signs
// them.
import { spawn, execFile } from "node:child_process"
import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, rmSync, statSync, writeFileSync } from "node:fs"
import { homedir } from "node:os"
import { delimiter, dirname, isAbsolute, join, resolve } from "node:path"
import { randomBytes } from "node:crypto"
import { STATUS_CODES } from "node:http"

const PROVIDER = "grok"
const BASE = "https://cli-chat-proxy.grok.com/v1"
const CLIENT_VERSION = "1.0.88" // https://x.ai/cli/stable
const CPA_CLIENT_ID = "b1a00492-073a-47ea-816f-4c329264a828"
const CPA_SCOPE = `https://auth.x.ai::${CPA_CLIENT_ID}`
const LOOP_CHECKS = [["x-grok-doom-loop-check", "1024"], ["x-grok-exact-repetition-check", "64"]]
const REFRESH_MARGIN = 5 * 60 * 1000 // a token this close to its end is renewed before a request
const LEAD_MS = REFRESH_MARGIN // and this close, magpie renews it ahead of time (auth.refresh)
const LINK_WAIT = 30 * 1000
// A local interaction deadline, not xAI's device-code expiry: Grok Build
// owns that expiry and doesn't expose it with the printed link.
const LOGIN_WAIT = 10 * 60 * 1000
const LOGIN_OUTPUT = 8192
// waits.renew is how long a request, model list or usage read Grok turned
// away waits on Grok Build's renewal before it gives up on it: the run
// goes on, and whoever asks next takes what it gave (plugins#818)
const waits = { renew: 15 * 1000 }
// TURNED_AWAY are the words of a 401 in which Grok judged the token
// itself: cli-chat-proxy answers a token it doesn't take, in under a
// second, `{"error":"Invalid or expired credentials (auth_kind=…,
// upstream=Unauthenticated, reason=…)"}`. Any other 401, such as the
// `{"error":"Authentication required"}` that came after 78–114 s on a token
// that worked again minutes later (plugins#818), isn't that judgement.
const TURNED_AWAY = /invalid or expired credentials/i
const RETRY_SECS = 60 // the Retry-After of a refusal that passes by itself
const INSTALL = process.platform === "win32" ? "irm https://x.ai/cli/install.ps1 | iex" : "curl -fsSL https://x.ai/cli/install.sh | bash"
// NO_CLI is what a sign-in without Grok Build says: how to install it, and
// that one put somewhere else by hand (a container with no shell to run the
// installer) is taken from GROK_BIN_DIR, as the installer's own folder is,
// while one found on PATH has to be under a .grok folder (yetone/magpie#2223)
const NO_CLI = `install Grok Build first: ${INSTALL}; or set GROK_BIN_DIR to the folder holding its grok binary`

// the tool types Grok's backend takes; it turns the whole request away over another
const TOOLS = new Set(["function", "web_search", "x_search", "image_generation", "collections_search", "file_search",
  "code_execution", "code_interpreter", "mcp", "shell", "tool_search"])

const ANSI = /\x1b\[[0-9;?]*[A-Za-z]/g
const LINK = /https:\/\/\S+/

// linkIn is the page a line of `grok login` gives to open, "" for none: a
// line saying it failed names the endpoint it couldn't reach (`Error: error
// sending request for url (https://auth.x.ai/oauth2/device/code): …`),
// which is no page to open.
const linkIn = (line) => (/\berror\b/i.test(line) ? "" : (line.match(LINK)?.[0] ?? ""))

// ---- the CLI ------------------------------------------------------------------

// cliHome is where the CLI keeps its own sign-in and settings.
function cliHome() {
  return process.env.GROK_HOME || join(homedir(), ".grok")
}

// ownHomes is where this plugin keeps a sign-in made beside the CLI's own.
function ownHomes() {
  return join(process.env.XDG_CONFIG_HOME || join(homedir(), ".config"), "opencode-grok-auth")
}

function isFile(p) {
  try {
    return statSync(p).isFile()
  } catch {
    return false
  }
}

// isGrokBuild tells xAI's grok from any other program by that name: its
// installer keeps it under the grok home.
function isGrokBuild(p) {
  let real = p
  try {
    real = realpathSync(p)
  } catch {}
  return real.replaceAll("\\", "/").toLowerCase().includes("/.grok/")
}

// executable finds the CLI, first to last: the installer's bin
// (GROK_BIN_DIR, GROK_HOME/bin, ~/.grok/bin), each folder on PATH, then
// ~/.local/bin; those two only when it is really Grok Build.
function executable() {
  const name = process.platform === "win32" ? "grok.exe" : "grok"
  const home = homedir()
  const seen = new Set()
  const out = []
  const add = (dir, own) => {
    if (!dir || !isAbsolute(dir)) return
    const p = join(dir, name)
    const k = process.platform === "win32" ? p.toLowerCase() : p
    if (seen.has(k)) return
    seen.add(k)
    out.push({ p, own })
  }
  add(process.env.GROK_BIN_DIR, true)
  add(join(cliHome(), "bin"), true)
  if (home) add(join(home, ".grok", "bin"), true)
  for (const d of (process.env.PATH ?? "").split(delimiter)) add(d.trim(), false)
  if (home) add(join(home, ".local", "bin"), false)
  for (const c of out) if (isFile(c.p) && (c.own || isGrokBuild(c.p))) return c.p
  return ""
}

// envFor runs the CLI as the user runs it, in the given home. GROK_AUTH_PATH
// goes too: grok 1.0.62 keeps its sign-in at that file instead of
// home/auth.json, where this plugin reads it, so a login with it set
// finished signed in and left nothing here.
function envFor(home) {
  const env = {}
  for (const [k, v] of Object.entries(process.env)) {
    if (["GROK_HOME", "GROK_AUTH_PATH", "GROK_AUTH_PROVIDER_COMMAND", "GROK_AUTH_EXPIRED"].includes(k.toUpperCase())) continue
    env[k] = v
  }
  env.GROK_HOME = home
  return env
}

// look reads the sign-in the CLI keeps in home: the first, by key, with a
// token. With none, why says what the file held instead.
//
// who is the account it is: its email, else its xAI user id (the token's
// subject when the file has none). grok 1.0.62 takes both from the
// sign-in's id_token and writes "email": null when that
// has no email claim (an xAI account signed in through X has none), and
// still says "✓ Signed in" (llllleo9 on 𝕏; seen with grok 1.0.62 in a
// sandbox, signed in against a stand-in auth.x.ai).
function look(home) {
  const file = join(home, "auth.json")
  let text
  try {
    text = readFileSync(file, "utf8")
  } catch (e) {
    return { c: null, why: e?.code === "ENOENT" ? `there is no ${file}` : `${file} can't be read (${e?.code ?? e?.message})` }
  }
  // an empty file, or one that isn't JSON, is most likely one the CLI is
  // writing as it is read (it rewrites auth.json when it renews): torn
  // says the read tells nothing, which read() tries again
  if (!text.trim()) return { c: null, why: `${file} is empty`, torn: true }
  let all
  try {
    all = JSON.parse(text)
  } catch {
    return { c: null, why: `${file} isn't JSON`, torn: true }
  }
  if (!all || typeof all !== "object" || Array.isArray(all)) return { c: null, why: `${file} holds no sign-in` }
  const keys = Object.keys(all).sort()
  for (const k of keys) {
    const c = all[k]
    if (c && typeof c.key === "string" && c.key) {
      const t = Date.parse(c.expires_at ?? "")
      const email = typeof c.email === "string" ? c.email : ""
      const sub = cpaClaims(c.key)?.sub
      const user = (typeof c.user_id === "string" && c.user_id) || (typeof sub === "string" ? sub : "")
      const got = { key: c.key, email, user, who: email || user, expires: Number.isFinite(t) ? t : 0, issuer: c.oidc_issuer ?? "" }
      lastGood.set(home, got)
      return { c: got, why: "" }
    }
  }
  return { c: null, why: keys.length ? `${file} has ${keys.join(", ")}, none with a token` : `${file} holds no sign-in` }
}

// lastGood is each home's last sign-in read whole.
const lastGood = new Map()
const TORN_TRIES = 6
const TORN_WAIT = 100

// read is look, a torn read (auth.json caught mid-write) tried again for
// about half a second; still torn, it is the last sign-in read whole there,
// as the CLI itself keeps its previous credentials when auth.json won't
// read ("auth reload: auth.json unreadable, keeping previous credentials").
// No lock is taken: the CLI's auth.json.lock is a flock it holds while it
// renews, which Node can't take, and a reader holding it could only hold a
// renewal back.
async function read(home, signal) {
  signal?.throwIfAborted()
  let r = look(home)
  for (let i = 1; r.torn && i < TORN_TRIES; i++) {
    await new Promise((ok, fail) => {
      const finish = () => { signal?.removeEventListener("abort", abort); ok() }
      const timer = setTimeout(finish, TORN_WAIT)
      const abort = () => {
        clearTimeout(timer)
        signal.removeEventListener("abort", abort)
        fail(signal.reason)
      }
      signal?.addEventListener("abort", abort, { once: true })
      if (signal?.aborted) abort()
    })
    signal?.throwIfAborted()
    r = look(home)
  }
  if (r.torn && lastGood.has(home)) return { c: lastGood.get(home), why: "" }
  return r
}

// credential is the sign-in in home, null when there is none. A file that
// stays torn, with nothing read there before, is unknown, not "not signed
// in": that is an error saying so.
async function credential(home, signal) {
  const r = await read(home, signal)
  if (r.torn) throw new Error(`Grok Build's sign-in couldn't be read (${r.why}); it may be mid-write, try again in a moment`)
  return r.c
}

// shared is whether home is Grok Build's own, which opening Grok Build
// renews; a home of this plugin's (a second account, an imported one) only
// this plugin's runs of the CLI ever touch.
function shared(home) {
  return resolve(home) === resolve(cliHome())
}

// notSignedIn says a home holds no sign-in, and what makes one.
function notSignedIn(home) {
  return shared(home)
    ? "Grok is not signed in; run `grok login`"
    : "Grok is not signed in for this account any more; add the account in magpie again"
}

// cliSaid is what a `grok models` that renewed nothing said: how it ended
// and its last line.
function cliSaid(r) {
  if (!r) return ""
  if (r.late) return ` (grok models was still running after ${waits.renew / 1000}s)`
  const last = (r.stderr || r.stdout || "").replace(ANSI, "").split("\n").map((l) => l.trim()).filter(Boolean).at(-1)?.slice(0, 200)
  const how = !r.err ? "ran and left the same token" : r.err.killed ? "timed out" : `exited ${r.err.code ?? "with an error"}`
  const took = r.ms >= 1000 ? ` in ${Math.round(r.ms / 1000)}s` : ""
  return ` (grok models ${how}${took}${last ? `: ${last}` : ""})`
}

// passing says a 401 on a token Grok Build left as it was is a refusal
// that passes by itself, not a sign-in to make again: Grok's words aren't
// its judgement of the token (TURNED_AWAY), the token isn't past its end,
// and the CLI didn't fail renewing it (it ran, or was still running). A
// token Grok really turned away, or one the CLI failed to renew, is
// unrenewed as before.
function passing(c, r, said) {
  if (typeof said !== "string" || TURNED_AWAY.test(said)) return false
  if (c.expires && c.expires <= Date.now()) return false
  return !r?.err || !!r.err.killed || !!r.late
}

// transient is such a refusal: what Grok said, that the sign-in stands,
// and that it is tried again later.
function transient(c, r, said) {
  const till = c.expires ? `, good till ${new Date(c.expires).toISOString()}` : ""
  const words = said.trim().slice(0, 200) || "an empty 401"
  return Object.assign(
    new Error(`Grok refused the request (${words}) on a sign-in that still holds: Grok Build left the token as it was${till}${cliSaid(r)}. Such a refusal has passed by itself within minutes; the account is tried again then, with no new sign-in needed`),
    { transient: true },
  )
}

// unrenewed is a token Grok turned away, or one past its end, that Grok
// Build, run in its home, didn't replace: the CLI couldn't renew it (xAI's renewal failing, or
// a refresh token used up elsewhere), which signing in with `grok login`
// in ~/.grok doesn't help where the account's home is the plugin's own.
function unrenewed(home, r) {
  const how = shared(home)
    ? "open Grok Build and send it a message, which renews the sign-in magpie reads"
    : "this account's sign-in is kept apart from Grok Build's own, so opening Grok Build doesn't renew it: add the account in magpie again"
  return Object.assign(new Error(`Grok Build couldn't renew the sign-in${cliSaid(r)}; ${how}`), { unrenewed: true })
}

// dead is a token Grok turned away even as Grok Build had just renewed it.
function dead(home) {
  return shared(home)
    ? "Grok turned away Grok Build's sign-in even after renewing it; run `grok login` to sign Grok Build in afresh"
    : "Grok turned away this account's sign-in even after renewing it; add the account in magpie again"
}

function run(file, args, opts) {
  const at = Date.now()
  return new Promise((resolve) => {
    execFile(file, args, { timeout: 30000, ...opts }, (err, stdout, stderr) =>
      resolve({ err, stdout: String(stdout ?? ""), stderr: String(stderr ?? ""), ms: Date.now() - at }),
    )
  })
}

// within is p, or { late: true } once ms have gone by without it.
function within(p, ms) {
  let t
  return Promise.race([p, new Promise((ok) => (t = setTimeout(() => ok({ late: true }), ms)))]).finally(() => clearTimeout(t))
}

// refreshing runs the CLI's renewals one after another; renewing is the one
// asked for each home, which those who come while it is due or running join
// rather than running the CLI there again.
let refreshing = Promise.resolve()
const renewing = new Map()

// renew has the CLI renew the sign-in in home: a `grok models` there renews
// it as any use of the CLI does.
function renew(exe, home) {
  let r = renewing.get(home)
  if (!r) {
    r = refreshing.then(() => run(exe, ["models"], { cwd: dirname(home), env: envFor(home) })).finally(() => renewing.delete(home))
    refreshing = r.catch(() => {})
    renewing.set(home, r)
  }
  return r
}

// token is the CLI's sign-in in home with a token still good. One about to
// expire is first renewed by the CLI in its own home, and so is one Grok
// turned away: rejected is that token (or true for whatever home holds).
// A token on disk other than the one turned away was renewed already and
// is taken as it is; one the CLI's run leaves as it was is unrenewed,
// never "not signed in" nor "expired". said is what Grok answered the
// token turned away with: a refusal that wasn't Grok's judgement of a
// token still good is transient (passing). A renewal for a token turned
// away is waited on waits.renew at most.
async function token(home, rejected = false, said) {
  let c = await credential(home)
  const exe = executable()
  const refused = !!c && (rejected === true || (typeof rejected === "string" && c.key === rejected))
  let r
  if (c && exe && (refused || c.expires - Date.now() < REFRESH_MARGIN)) {
    const was = c.key
    r = refused ? await within(renew(exe, home), waits.renew) : await renew(exe, home)
    c = await credential(home)
    if (c && refused && c.key === was) throw passing(c, r, said) ? transient(c, r, said) : unrenewed(home, r)
  }
  if (!c) throw new Error(notSignedIn(home))
  if (!exe && (refused || (c.expires && c.expires <= Date.now()))) throw new Error(`Grok turned the sign-in away and there is no Grok Build here to renew it; ${NO_CLI}`)
  if (c.expires && c.expires <= Date.now()) throw unrenewed(home, r)
  return c
}

let version = { v: CLIENT_VERSION, at: 0 }

// clientVersion is the CLI version the requests say they come from, unless
// the installed one is newer: without it the backend calls the CLI outdated.
async function clientVersion() {
  if (Date.now() - version.at < 10 * 60 * 1000) return version.v
  let v = CLIENT_VERSION
  const exe = executable()
  if (exe) {
    const { err, stdout } = await run(exe, ["--version"], { timeout: 5000 }) // "grok 1.0.88 (2fe3608f7398)"
    const got = !err && stdout.match(/\d+\.\d+\.\d+/)?.[0]
    if (got && newer(got, v)) v = got
  }
  version = { v, at: Date.now() }
  return v
}

function newer(a, b) {
  const x = a.split(".").map(Number), y = b.split(".").map(Number)
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i]
  return false
}

// headers say a request comes from the Grok CLI.
async function sign(headers, key, url) {
  const v = await clientVersion()
  const os = process.platform === "darwin" ? "macos" : process.platform === "win32" ? "windows" : process.platform
  const arch = { arm64: "aarch64", x64: "x86_64", ia32: "x86" }[process.arch] ?? process.arch
  headers.set("Authorization", `Bearer ${key}`)
  headers.set("x-grok-client-version", v)
  headers.set("x-xai-token-auth", "xai-grok-cli")
  headers.set("x-grok-client-identifier", "grok-shell")
  headers.set("x-grok-client-mode", "headless")
  // Grok Build's agent/proxy_headers.rs adds this auth marker only at the
  // CLI proxy boundary; STT goes directly to api.x.ai, without it.
  if (new URL(url).hostname === new URL(BASE).hostname) headers.set("x-authenticateresponse", "authenticate-response")
  headers.set("User-Agent", `grok-shell/${v} (${os}; ${arch})`)
}

// bodyText is a request body handed over as bytes read as the text it
// is, so it can be reshaped; any other body is as it came.
function bodyText(body) {
  if (body instanceof ArrayBuffer || ArrayBuffer.isView(body)) return new TextDecoder().decode(body)
  return body
}

// objectRoot is a tool's parameters as a plain object at the root, with no
// anyOf, oneOf or allOf there, folded as magpie's built-in folds them
// (provider.ObjectRoot): allOf's branches are all merged; of anyOf's and
// oneOf's object branches, a union itself folded first, the properties are
// merged, a field each of them requires stays required, and the other
// branches go. Branches may be local $refs. A schema already a plain object
// is returned as it came; the caller's own is never changed.
function objectRoot(ps) {
  return foldRoot(ps, ps, 0)
}

function foldRoot(root, ps, depth) {
  if (!isObj(ps)) return ps
  const has = (k) => Object.hasOwn(ps, k)
  if (ps.type === "object" && !has("anyOf") && !has("oneOf") && !has("allOf")) return ps
  const out = { ...ps }
  const props = { ...(isObj(ps.properties) ? ps.properties : {}) }
  let required = Array.isArray(ps.required) ? [...ps.required] : []
  const ref = (b) => {
    if (!isObj(b)) return null
    if (typeof b.$ref !== "string" || !b.$ref) return b
    for (const k of ["$defs", "definitions"]) {
      const pre = "#/" + k + "/"
      if (b.$ref.startsWith(pre)) {
        const d = root[k]?.[b.$ref.slice(pre.length)]
        return isObj(d) ? d : null
      }
    }
    return null
  }
  for (const b of Array.isArray(ps.allOf) ? ps.allOf : []) {
    const bm = ref(b)
    if (!bm) continue
    if (isObj(bm.properties)) for (const [k, v] of Object.entries(bm.properties)) if (!Object.hasOwn(props, k)) props[k] = v
    if (Array.isArray(bm.required)) required.push(...bm.required)
  }
  delete out.allOf
  const branches = []
  for (const k of ["anyOf", "oneOf"]) {
    for (const b of Array.isArray(ps[k]) ? ps[k] : []) {
      let bm = ref(b)
      if (!bm) continue
      // a branch that is itself a union (zod's discriminated create and
      // update in automation_update) is folded first, not dropped
      if (depth < 8 && ["anyOf", "oneOf", "allOf"].some((u) => Object.hasOwn(bm, u))) bm = foldRoot(root, bm, depth + 1)
      if (bm.type !== "object" && !Object.hasOwn(bm, "properties")) continue
      branches.push(bm)
    }
    delete out[k]
  }
  // a field every branch requires stays required, beside the root's and
  // allOf's own, which no branch can drop; a field the root doesn't define
  // takes each schema the branches give it, as anyOf when they differ
  let common = null
  const from = new Map()
  for (const b of branches) {
    for (const [k, v] of Object.entries(isObj(b.properties) ? b.properties : {})) {
      if (Object.hasOwn(props, k)) continue
      const vs = from.get(k) ?? []
      if (!vs.some((w) => JSON.stringify(w) === JSON.stringify(v))) vs.push(v)
      from.set(k, vs)
    }
    const br = Array.isArray(b.required) ? b.required : []
    common = common === null ? [...br] : common.filter((r) => br.includes(r))
  }
  for (const [k, vs] of from) props[k] = vs.length === 1 ? vs[0] : { anyOf: vs }
  for (const r of common ?? []) if (!required.includes(r)) required.push(r)
  required = [...new Set(required)]
  out.type = "object"
  out.properties = props
  if (required.length) out.required = required
  else delete out.required
  return out
}

// what Codex asks an OpenAI provider for with output token replay on
// (codex-rs/core/src/client.rs)
const OUTPUT_REPLAY = "output.encrypted_content"

const isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v)

// rewrite leaves out what Grok's backend doesn't take: tools of other
// types (a freeform apply_patch, a namespace of sub-agent tools), a web
// search's external_web_access, a tool_choice naming a dropped type or
// with no tools beside it (magpie sends "none" so when a client turned
// tools off, yetone/magpie#3110; Grok refuses it: "A tool_choice was set on
// the request but no tools were specified"), and a
// reasoning item's "content": null, beside which it can't read the
// encrypted reasoning. A function's parameters with a union at the root
// (Codex desktop's codex_app automation_update) are folded to an object,
// which Grok turns away otherwise: "tool parameter root must be an object
// type" (magpie#1271). Codex's output token replay asks for each message's
// own sealed copy ("output.encrypted_content" in include), which Grok turns
// away: 'Argument not supported: "output.encrypted_content" in "include"
// field' (#524). Only that value goes; reasoning.encrypted_content and the
// tool-output values xAI documents stay.
function rewrite(body, xSearch = false) {
  if (typeof body !== "string" || (!xSearch && !body.includes('"tools"') && !body.includes('"tool_choice"') && !body.includes('"reasoning"') && !body.includes('"agent_message"') && !body.includes(`"${OUTPUT_REPLAY}"`))) return body
  let m
  try {
    m = JSON.parse(body)
  } catch {
    return body
  }
  if (!m || typeof m !== "object" || Array.isArray(m)) return body
  // Read the client's choice before dropping unsupported tools or choices.
  const search = xSearch && (m.tool_choice == null || m.tool_choice === "auto") &&
    (m.tools == null || Array.isArray(m.tools)) &&
    (m.tool_choice === "auto" || Array.isArray(m.tools) && m.tools.length > 0)
  let dirty = false
  if (Array.isArray(m.tools)) {
    m.tools = m.tools.filter((t) => {
      if (!t || typeof t !== "object") return true
      if (!TOOLS.has(t.type)) {
        dirty = true
        return false
      }
      if ("external_web_access" in t) {
        delete t.external_web_access
        dirty = true
      }
      if (t.type === "function") {
        const fn = isObj(t.function) ? t.function : t
        const ps = objectRoot(fn.parameters)
        if (ps !== fn.parameters) {
          fn.parameters = ps
          dirty = true
        }
      }
      return true
    })
    if (m.tool_choice && typeof m.tool_choice === "object" && !TOOLS.has(m.tool_choice.type)) {
      delete m.tool_choice
      dirty = true
    }
  }
  // No choice and no tools can mean a translated "none" on older gateways.
  if (search && (m.tool_choice === "auto" || m.tools?.length) && !m.tools?.some((t) => t?.type === "x_search")) {
    m.tools ??= []
    m.tools.push({ type: "x_search" })
    dirty = true
  }
  if (Object.hasOwn(m, "tool_choice") && !(Array.isArray(m.tools) && m.tools.length)) {
    delete m.tool_choice
    dirty = true
  }
  if (Array.isArray(m.input)) {
    m.input = m.input.map((it) => {
      if (!isObj(it) || it.type !== "agent_message" || Object.hasOwn(it, "encrypted_content") ||
          !Array.isArray(it.content) || !it.content.length ||
          !it.content.every((part) => isObj(part) && !Object.hasOwn(part, "encrypted_content") &&
            (part.type === "input_text" && typeof part.text === "string" ||
             part.type === "input_image" && typeof part.image_url === "string"))) return it
      // Grok takes ordinary messages, not Codex's collaboration item.
      // Sealed tasks remain untouched for the gateway's existing guard.
      const from = typeof it.author === "string" ? it.author : ""
      const to = typeof it.recipient === "string" ? it.recipient : ""
      const header = from && to ? `From ${from} to ${to}` : from ? `From ${from}` : to ? `To ${to}` : ""
      dirty = true
      return { type: "message", role: "user", content: header
        ? [{ type: "input_text", text: `${header}\n\n` }, ...it.content] : it.content }
    })
  }
  if (Array.isArray(m.include) && m.include.includes(OUTPUT_REPLAY)) {
    m.include = m.include.filter((v) => v !== OUTPUT_REPLAY)
    if (!m.include.length) delete m.include
    dirty = true
  }
  for (const it of Array.isArray(m.input) ? m.input : []) {
    if (it && it.type === "reasoning" && "content" in it && it.content === null) {
      delete it.content
      dirty = true
    }
  }
  return dirty ? JSON.stringify(m) : body
}

// ---- models -------------------------------------------------------------------

// the levels the built-in offered for grok-4.7 before Grok listed any (its
// maker's, as models.dev has them): kept when the list can't be read, so
// a move leaves an agent's reasoning level where it was
const DEFAULT_EFFORTS = ["low", "medium", "high", "xhigh"]

const DEFAULT_MODELS = {
  "grok-4.7": {
    name: "Grok 4.7",
    attachment: true,
    reasoning: true,
    tool_call: true,
    modalities: { input: ["text", "image"], output: ["text"] },
    variants: Object.fromEntries(DEFAULT_EFFORTS.map((e) => [e, { reasoningEffort: e }])),
  },
}

// listModels is what the account can use, as the CLI's backend lists it:
// Responses models only, each with its context window and efforts
// (listed hardest first, kept easiest first).
async function listModels(key) {
  const headers = new Headers()
  await sign(headers, key, BASE)
  const res = await fetch(`${BASE}/models`, { headers })
  const text = await res.text()
  // a token Grok turned away before its time: the caller has Grok Build
  // renew it and asks once more (models below)
  if (res.status === 401) throw Object.assign(new Error("Grok turned the sign-in away"), { status: 401, said: text })
  if (!res.ok) throw new Error(`Grok models: ${res.status} ${text.slice(0, 200)}`)
  const out = []
  for (const d of JSON.parse(text)?.data ?? []) {
    if (!d?.id || (d.api_backend && d.api_backend !== "responses")) continue
    const efforts = (d.reasoning_efforts ?? []).map((e) => e?.value).filter(Boolean).reverse()
    out.push(...windowsOf(d, efforts))
  }
  if (!out.length) throw new Error("Grok listed no models")
  return out
}

// labelOf is a window as the picker shows it: 500000 is "500k".
const labelOf = (n) => (n % 1000 === 0 ? `${n / 1000}k` : String(n))

// windowsOf is one model for each context window Grok lists. context_window
// is the default and keeps the plain id (grok-4.7), so a saved agent stays
// where it was. Each other size in context_windows is offered beside it
// (grok-4.7@500k), the way the CLI's /context-window offers it. A list with
// one size, or none, stays one model.
function windowsOf(d, efforts) {
  const name = d.name || d.id
  const fallback = Number(d.context_window) || 0
  const listed = (Array.isArray(d.context_windows) ? d.context_windows : [])
    .map(Number)
    .filter((n) => Number.isInteger(n) && n > 0)
  const windows = [...new Set(listed.length ? listed : [fallback].filter(Boolean))]
  const base = windows.includes(fallback) ? fallback : windows[0] ?? 0
  const out = [{ id: d.id, apiId: d.id, name, context: base || fallback, window: base, efforts }]
  for (const w of windows) {
    if (w === base) continue
    out.push({ id: `${d.id}@${labelOf(w)}`, apiId: d.id, name: `${name} @ ${labelOf(w)}`, context: w, window: w, efforts })
  }
  return out
}

// modelOf splits a requested id into the model Grok lists and the window
// the id names. grok-4.7 is grok-4.7 at its default window (no header);
// grok-4.7@500k is grok-4.7 at 500000 tokens. The header is what the CLI
// sends as x-grok-context-window. The proxy serves up to its largest
// window either way and refuses past it; the header names the window the
// caller asked to compact against. A window no multiple of 1000 is named
// by its digits alone (grok-4.7@131072), as labelOf writes it.
function modelOf(id) {
  const at = typeof id === "string" ? id.match(/^(.+)@(\d+)(k?)$/) : null
  if (!at || !(Number(at[2]) > 0)) return { model: id, window: 0 }
  return { model: at[1], window: Number(at[2]) * (at[3] ? 1000 : 1) }
}

// ---- sign-in ------------------------------------------------------------------

// opensPage is whether `grok login --device-auth` opens its page in the
// browser itself, which it does wherever it can: on macOS (NSWorkspace) and
// Windows (ShellExecute) always, with nothing to turn it off; on Linux and
// the BSDs through $BROWSER, else xdg-open where a display is. There it is
// given a $BROWSER that opens nothing, and the one who asked (magpie, which
// knows where the user's browser is) opens it; here the sign-in says the
// page is open already, so it isn't opened a second time (andyfmyth on X:
// "每次都会弹两次验证").
const opensPage = () => process.platform === "darwin" || process.platform === "win32"

function newHome() {
  const home = join(ownHomes(), randomBytes(9).toString("base64url").replace(/[-_]/g, "").toLowerCase())
  mkdirSync(home, { recursive: true, mode: 0o700 })
  return home
}

// Only homes allocated by this attempt or import batch go here, never cliHome.
function dropHome(home) {
  lastGood.delete(home)
  rmSync(home, { recursive: true, force: true })
}

// DeviceLogin owns the command, its waits and its not-yet-saved home, even
// when the caller never asks for the callback.
// decision: bound the native CLI interaction locally; not parse an expiry
// from its prose because the printed link has no device-code lifetime;
// revisit when Grok Build exposes a machine-readable device expiry.
class DeviceLogin {
  constructor(exe, home, own, signal) {
    this.home = home
    this.own = own
    this.buf = ""
    this.last = ""
    this.watches = new Map()
    this.readAbort = new AbortController()
    this.link = new Promise((ok) => (this.found = ok))
    this.done = new Promise((ok) => (this.ended = ok))
    this.stopped = new Promise((ok) => (this.reaped = ok))
    this.linkTimer = setTimeout(() => this.fail(this.noLink()), LINK_WAIT)
    this.deadline = setTimeout(() => this.fail(new Error("Grok Build sign-in exceeded this plugin's 10-minute wait; start the sign-in again")), LOGIN_WAIT)
    const env = envFor(home)
    if (!opensPage()) env.BROWSER = "true"
    this.onData = (chunk) => {
      this.buf += chunk.toString()
      let i
      while ((i = this.buf.indexOf("\n")) >= 0) {
        this.line(this.buf.slice(0, i))
        this.buf = this.buf.slice(i + 1)
      }
      this.buf = this.buf.slice(-LOGIN_OUTPUT)
    }
    try {
      this.child = spawn(exe, ["login", "--device-auth"], { cwd: homedir(), env, stdio: ["ignore", "pipe", "pipe"] })
      this.child.stdout.on("data", this.onData)
      this.child.stderr.on("data", this.onData)
      this.onError = (e) => {
        this.last = e.message
        this.fail(this.hasLink ? e : this.noLink())
      }
      this.child.once("error", this.onError)
      this.onExit = () => { this.exited = true; this.reaped() }
      this.child.once("exit", this.onExit)
      this.child.once("close", (code) => {
        this.exited = true
        this.child.removeListener("error", this.onError)
        this.child.removeListener("exit", this.onExit)
        this.child.stdout.removeListener("data", this.onData)
        this.child.stderr.removeListener("data", this.onData)
        this.line(this.buf)
        this.buf = ""
        this.reaped()
        if (!this.hasLink) this.fail(this.noLink())
        else if (code !== 0) this.fail(new Error(this.last || "grok login didn't finish"))
        else this.ended({ ok: true })
      })
      this.watch(signal)
    } catch (e) {
      this.exited = true
      this.reaped()
      this.last = e.message
      this.fail(this.noLink())
    }
  }

  line(text) {
    const line = text.replace(ANSI, "").trim().slice(-LOGIN_OUTPUT)
    if (line) this.last = line
    const url = !this.failure && linkIn(line)
    if (url && !this.hasLink) {
      this.hasLink = true
      clearTimeout(this.linkTimer)
      this.found(url)
    }
  }

  noLink() {
    // Keep the CLI's own diagnosis, including proxy/network failures.
    return new Error(this.last ? `grok login gave no link to open: ${this.last}` : "grok login gave no link to open and said nothing: can this machine reach auth.x.ai? Set a proxy in magpie's Settings if it needs one")
  }

  watch(signal) {
    if (!signal || this.committed || this.failure || this.watches.has(signal)) return
    const abort = () => this.fail(signal.reason ?? new Error("Grok Build sign-in was cancelled"))
    this.watches.set(signal, abort)
    signal.addEventListener("abort", abort, { once: true })
    if (signal.aborted) abort()
  }

  clear() {
    clearTimeout(this.linkTimer)
    clearTimeout(this.deadline)
    for (const [signal, abort] of this.watches) signal.removeEventListener("abort", abort)
    this.watches.clear()
  }

  fail(error) {
    if (this.committed || this.failure) return
    this.failure = error instanceof Error ? error : new Error(String(error ?? "Grok Build sign-in was cancelled"))
    this.clear()
    this.readAbort.abort(this.failure)
    this.found("")
    this.ended({ ok: false })
    // Reap the writer before deleting its home: otherwise a late write can
    // recreate a cancelled account. SIGKILL also bounds a CLI ignoring TERM.
    // Close pipes too: a browser inheriting them must not hold cleanup open
    // after the login process exits.
    if (this.child) {
      for (const stream of [this.child.stdout, this.child.stderr]) {
        stream.removeListener("data", this.onData)
        stream.destroy?.()
      }
      if (!this.exited) this.child.kill("SIGKILL")
    }
    this.cleanup = this.stopped.then(() => {
      if (this.own) dropHome(this.home)
    }).catch((e) => { this.failure = new Error(`${this.failure?.message ?? this.failure}; home cleanup failed: ${e.message}`) })
  }

  finish(signal) {
    // A repeated callback shares the result; it can't cancel a saved home.
    this.watch(signal)
    this.result ??= this.complete()
    return this.result
  }

  async complete() {
    try {
      const r = await this.done
      if (!r.ok || this.failure) throw this.failure
      const { c, why } = await read(this.home, this.readAbort.signal)
      if (this.failure) throw this.failure
      if (!c || (this.own && !c.who)) {
        const said = this.last ? ` (it said "${this.last}")` : ""
        throw new Error(!c
          ? `grok login finished${said}, but left no sign-in where this plugin reads it: ${why}. Run \`grok login\` in a terminal, then add Grok with "Use Grok Build's current sign-in"`
          : `grok login finished${said}, but its sign-in in ${join(this.home, "auth.json")} names no account (no email, user id or token subject), so it can't be told from the Grok Build sign-in in ${cliHome()}. Sign in to that one with \`grok login\` and add it with "Use Grok Build's current sign-in"`)
      }
      this.committed = true
      this.clear()
      return saved(this.home, c)
    } catch (e) {
      this.fail(e)
      await this.cleanup
      return { type: "failed", error: String(this.failure?.message ?? this.failure) }
    }
  }
}

// signIn keeps Grok Build's native device flow and renewal owner.
async function signIn(_inputs, { signal } = {}) {
  signal?.throwIfAborted()
  const exe = executable()
  if (!exe) throw new Error(NO_CLI)
  // a sign-in mid-write is one: the CLI's own home is left be
  const own = await credential(cliHome(), signal).then((c) => !!c, () => true)
  signal?.throwIfAborted()
  const attempt = new DeviceLogin(exe, own ? newHome() : cliHome(), own, signal)
  const url = await attempt.link
  if (!url || attempt.failure) {
    await attempt.cleanup
    throw attempt.failure
  }
  return {
    url,
    // not OpenCode's: the page is open already, by Grok Build itself
    opened: opensPage(),
    instructions: "Approve the sign-in on the page; Grok Build finishes it. This plugin waits up to 10 minutes; cancel or start again if needed.",
    method: "auto",
    callback: (_code, { signal: callbackSignal } = {}) => attempt.finish(callbackSignal),
  }
}

function cpaClaims(token) {
  try {
    const part = token.split(".")[1]
    if (!part) return null
    return JSON.parse(Buffer.from(part, "base64url").toString("utf8"))
  } catch {
    return null
  }
}

// CPA and sub2api use the same xAI client by default. sub2api can override
// it, so an explicit client_id and the token's issuer/audience must agree
// with Grok Build before its CLI can own renewal of the imported account.
function importedAuth(source, from) {
  const cpa = from === "CPA"
  if (!isObj(source)) throw new Error(`${from} Grok account is missing its credentials`)
  if (cpa && source.disabled !== false) throw new Error("CPA file is not an enabled xAI OAuth account")
  const string = (v) => typeof v === "string" ? v.trim() : ""
  if (!string(source.access_token) || !string(source.refresh_token)) throw new Error(`${from} xAI account is missing its tokens or identity`)
  const claims = cpaClaims(source.access_token)
  const audience = Array.isArray(claims?.aud) ? claims.aud : [claims?.aud]
  if (claims?.iss !== "https://auth.x.ai" || !audience.includes(CPA_CLIENT_ID)) throw new Error(`${from} token is not for the Grok Build xAI account (issuer/audience mismatch)`)
  if (source.client_id !== undefined && source.client_id !== CPA_CLIENT_ID) throw new Error(`${from} client_id is not Grok Build's xAI client`)
  const user = string(source.sub) || (!cpa ? string(source.user_id) || string(claims.sub) : "")
  const email = string(source.email)
  if (!user || (cpa && !email)) throw new Error(`${from} xAI account is missing its tokens or identity`)
  const expires = cpa ? source.expired : source.expires_at
  const created = cpa ? source.last_refresh : new Date().toISOString()
  // BuildAccountCredentials in sub2api writes RFC3339, not Unix seconds.
  if (typeof created !== "string" || typeof expires !== "string" || (!cpa && !RFC3339.test(expires)) || !Number.isFinite(Date.parse(created)) || !Number.isFinite(Date.parse(expires))) {
    throw new Error(`${from} xAI account has invalid token timestamps`)
  }
  return {
    key: source.access_token,
    auth_mode: "oidc",
    create_time: new Date(created).toISOString(),
    user_id: user,
    email: email || null,
    refresh_token: source.refresh_token,
    expires_at: new Date(expires).toISOString(),
    oidc_issuer: "https://auth.x.ai",
    oidc_client_id: CPA_CLIENT_ID,
  }
}

const IMPORT_FROM = "Choose CPA xAI OAuth account JSON or sub2api Grok OAuth account/export JSON files, or paste their JSON. Other platforms and non-OAuth accounts are skipped. Stop using these accounts in CPA or sub2api before continuing: both clients rotate the same refresh token. Source files and accounts are left unchanged."

function importEntries(texts) {
  const entries = []
  for (const text of texts) {
    try {
      const source = JSON.parse(text)
      let accounts
      if (Array.isArray(source)) accounts = source
      else if (isObj(source) && Array.isArray(source.accounts)) {
        if ((source.type !== undefined && source.type !== "sub2api-data") || (source.version !== undefined && source.version !== 1)) throw new Error("unsupported sub2api export type or version")
        accounts = source.accounts
      } else accounts = [source]
      let matched = false
      for (const account of accounts) {
        if (!isObj(account)) continue
        const cpa = account.type === "xai" && account.auth_kind === "oauth"
        if (!cpa && !(account.platform === "grok" && account.type === "oauth")) continue
        matched = true
        try {
          entries.push({ auth: importedAuth(cpa ? account : account.credentials, cpa ? "CPA" : "sub2api") })
        } catch (e) {
          entries.push({ type: "failed", error: e.message })
        }
      }
      if (!matched && !accounts.every((a) => isObj(a) && (typeof a.platform === "string" || a.type === "xai"))) {
        entries.push({ type: "failed", error: "no CPA xAI or sub2api Grok OAuth account in this JSON" })
      }
    } catch (e) {
      entries.push({ type: "failed", error: e instanceof SyntaxError ? "Grok account import is not valid JSON" : e.message })
    }
  }
  return entries
}

const identityKeys = (c) => [c.user_id || c.user ? `user:${c.user_id || c.user}` : "", c.email ? `email:${c.email}` : ""].filter(Boolean)

// An import is one transaction until its results are returned to magpie.
// A cancelled batch drops every new home, not an existing sign-in it reused.
class ImportBatch {
  constructor(signal) {
    this.signal = signal
    this.homes = new Set()
    this.accounts = new Map()
    this.tokens = new Set()
  }

  async existing() {
    const homes = [cliHome()]
    if (existsSync(ownHomes())) for (const d of readdirSync(ownHomes(), { withFileTypes: true })) if (d.isDirectory()) homes.push(join(ownHomes(), d.name))
    for (const home of homes) {
      this.signal?.throwIfAborted()
      const c = await credential(home, this.signal).catch(() => null)
      this.signal?.throwIfAborted()
      if (c) for (const k of identityKeys(c)) if (!this.accounts.has(k)) this.accounts.set(k, saved(home, c))
    }
  }

  async add(auth) {
    this.signal?.throwIfAborted()
    const keys = identityKeys(auth)
    // One account twice in pasted files or mixed exports makes one home.
    if (keys.some((k) => this.tokens.has(k)) || this.tokens.has(auth.refresh_token)) return null
    for (const k of [...keys, auth.refresh_token]) this.tokens.add(k)
    const existing = keys.map((k) => this.accounts.get(k)).find(Boolean)
    if (existing) return existing
    const home = newHome()
    this.homes.add(home)
    try {
      writeFileSync(join(home, "auth.json"), JSON.stringify({ [CPA_SCOPE]: auth }, null, 2), { mode: 0o600 })
      const c = await credential(home, this.signal)
      this.signal?.throwIfAborted()
      if (!c?.who) throw new Error("imported Grok Build sign-in has no account identity")
      const result = saved(home, c)
      for (const k of keys) this.accounts.set(k, result)
      return result
    } catch (e) {
      dropHome(home)
      this.homes.delete(home)
      throw e
    }
  }

  async run(entries) {
    try {
      this.signal?.throwIfAborted()
      if (!executable()) throw new Error(NO_CLI)
      await this.existing()
      const results = []
      for (const e of entries) {
        this.signal?.throwIfAborted()
        if (!e.auth) { results.push(e); continue }
        try {
          const result = await this.add(e.auth)
          if (result) results.push(result)
        } catch (error) {
          this.signal?.throwIfAborted()
          results.push({ type: "failed", error: error.message })
        }
      }
      this.signal?.throwIfAborted()
      this.homes.clear()
      return results
    } finally {
      for (const home of this.homes) dropHome(home)
      this.homes.clear()
    }
  }
}

async function importAccounts(texts, { signal } = {}) {
  signal?.throwIfAborted()
  return new ImportBatch(signal).run(importEntries(Array.isArray(texts) ? texts : [texts]))
}

// OpenCode's single-account method keeps its path prompt; JSON pasted into
// the same prompt goes through the very same parser and writer as magpie.
async function importCPA(inputs, { signal } = {}) {
  signal?.throwIfAborted()
  if (!executable()) throw new Error(NO_CLI)
  let text = String(inputs?.path ?? "").trim()
  if (!text.startsWith("{") && !text.startsWith("[")) {
    const file = resolve(text === "~" ? homedir() : text.startsWith("~/") ? join(homedir(), text.slice(2)) : text)
    if (!isFile(file)) throw new Error("choose a CPA or sub2api Grok account JSON file, or paste JSON")
    text = readFileSync(file, "utf8")
  }
  const entries = importEntries([text])
  const failed = entries.find((e) => e.error)
  if (failed) throw new Error(failed.error)
  if (!entries.length) throw new Error("no CPA xAI or sub2api Grok OAuth account in this JSON")
  // This callback saves one account. magpie's file/paste import saves a batch.
  const unique = new Map(entries.map((e) => [e.auth.user_id, e]))
  if (unique.size !== 1) throw new Error("use magpie's Import accounts from a file to import multiple Grok accounts")
  let result
  return {
    url: "",
    instructions: IMPORT_FROM,
    method: "auto",
    callback: (_code, { signal: callbackSignal } = {}) => {
      result ??= new ImportBatch(signal && callbackSignal ? AbortSignal.any([signal, callbackSignal]) : callbackSignal ?? signal).run([...unique.values()]).then((results) => results[0])
      return result
    },
  }
}

// saved is the sign-in as OpenCode keeps it: refresh is the home the CLI
// keeps it in, access the token it had then.
function saved(home, c) {
  return { type: "success", refresh: home, access: c.key, expires: c.expires, accountId: c.who }
}

// current takes the sign-in the CLI already has, as it is.
async function current() {
  if (!executable()) throw new Error(NO_CLI)
  const home = cliHome()
  if (!(await credential(home))) throw new Error("Grok Build is not signed in; run `grok login`, or sign in with the device code")
  const c = await token(home)
  return {
    url: "",
    instructions: c.email ? `Grok Build is signed in as ${c.email}.` : "Grok Build is signed in.",
    method: "auto",
    callback: async () => saved(home, c),
  }
}

// ---- usage ----------------------------------------------------------------------

// How much of the subscription's allowance is gone, as magpie's built-in
// Grok account shows it (internal/provider/grok_usage.go) and the CLI's own
// /usage reads it: the credits of the current period, weekly for
// SuperGrok, and what on-demand spending has used of its cap.

const PERIODS = { DAILY: ["1 day", 24 * 3600], WEEKLY: ["7 days", 7 * 24 * 3600], MONTHLY: ["Month", 30 * 24 * 3600] }
const RFC3339 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$/

// statusText is a refused request's status as magpie says it (Go's
// http.StatusText).
// http.StatusText); one Go has no words for is "HTTP <n>", never empty.
const statusText = (s) =>
  ((GO_TEXT[s] ?? STATUS_CODES[s]) || `HTTP ${s}`)
// where Go's words differ from Node's (509 Go has none for)
const GO_TEXT = { 413: "Request Entity Too Large", 414: "Request URI Too Long", 416: "Requested Range Not Satisfiable", 418: "I'm a teapot", 509: "" }

// netError is a request that got no answer, as Go's http client words it
// (`Get "<url>": …`), with the words magpie's keepLast looks for to keep
// the card it had: no such host, connection refused, timeout, EOF.
function netError(url, e) {
  const m = String(e?.message ?? e)
  const code = String(e?.code ?? e?.cause?.code ?? "")
  let why = m
  if (e?.name === "TimeoutError" || e?.name === "AbortError" || /timed? ?out/i.test(m)) why = "timeout"
  else if (code === "ENOTFOUND" || code === "EAI_AGAIN" || /getaddrinfo|ENOTFOUND|resolve|DNS/i.test(m)) why = "dial tcp: lookup: no such host"
  else if (code === "ECONNREFUSED" || /ECONNREFUSED|Unable to connect|refused/i.test(m)) why = "dial tcp: connection refused"
  else if (/ECONNRESET|socket|closed|fetch failed/i.test(m + code)) why = "EOF"
  return `Get "${url}": ${why}`
}

// jsonError is JSON that won't read, as Go's encoding/json says it.
function jsonError(text) {
  const c = text.trimStart()[0]
  return c === undefined ? "unexpected end of JSON input" : `invalid character '${c}' looking for beginning of value`
}

async function usage(key) {
  const url = `${BASE}/billing?format=credits`
  let res, text
  try {
    res = await fetch(url, {
      headers: { Authorization: `Bearer ${key}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000),
    })
    if (res.ok) text = await res.text()
  } catch (e) {
    return { error: netError(url, e), windows: [] }
  }
  if (!res.ok) return { error: statusText(res.status), windows: [], status: res.status, said: await res.text().catch(() => "") }
  let data
  try {
    data = JSON.parse(text)
  } catch {
    return { error: jsonError(text), windows: [] }
  }
  const cfg = data?.config ?? {}
  const num = (v) => (typeof v === "number" ? v : 0)
  let [name, span] = ["Allowance", 0]
  let end = cfg.billingPeriodEnd
  if (cfg.currentPeriod) {
    ;[name, span] = PERIODS[String(cfg.currentPeriod.type ?? "").replace(/^USAGE_PERIOD_TYPE_/, "")] ?? ["Allowance", 0]
    end = cfg.currentPeriod.end
  }
  const at = typeof end === "string" && RFC3339.test(end) && !Number.isNaN(Date.parse(end)) ? { resetsAt: end } : {}
  const out = [{ name, used: num(cfg.creditUsagePercent), ...(span ? { span } : {}), ...at }]
  const cap = num(cfg.onDemandCap?.val)
  if (cap > 0) out.push({ name: "On-demand", used: (100 * num(cfg.onDemandUsed?.val)) / cap, ...at, aside: true })
  return { windows: out }
}

// ---- rate limit -------------------------------------------------------------------

// Grok's billing says nothing of a plan's rate limit: a free account's
// credits read 0% used while every request comes back 429. So the account's
// last 429 is kept here, by its CLI home, and usage shows a "Rate limit"
// window spent until the reset the 429 named (Retry-After, or a
// *ratelimit*reset* header), or, when it named none, until a request goes
// through or HOLD_MS has passed. Aside: magpie's gateway already rests an
// account that answered 429; this is only what the card says.
const HOLD_MS = 5 * 60_000
const limited = new Map()

// resetOf is when a 429 says the limit lifts, in ms since the epoch, or 0.
function resetOf(headers, now) {
  const ra = headers.get("retry-after")
  if (ra) {
    const n = Number(ra)
    if (Number.isFinite(n) && n >= 0) return now + n * 1000
    const d = Date.parse(ra)
    if (!Number.isNaN(d)) return d
  }
  for (const [k, v] of headers) {
    if (!/ratelimit.*reset/i.test(k)) continue
    const n = Number(v)
    if (!Number.isFinite(n) || n < 0) continue
    // a time (epoch ms or seconds) or seconds from now
    if (n > 1e12) return n
    if (n > 1e9) return n * 1000
    return now + n * 1000
  }
  return 0
}

// note keeps what a request's answer says of the rate limit.
function note(home, res, now = Date.now()) {
  if (res.status === 429) limited.set(home, { at: now, until: resetOf(res.headers, now) })
  else if (res.ok) limited.delete(home)
}

// rateWindow is the window a recent 429 makes, or none.
function rateWindow(home, now = Date.now()) {
  const l = limited.get(home)
  if (!l) return []
  if (l.until ? l.until <= now : now - l.at >= HOLD_MS) {
    limited.delete(home)
    return []
  }
  const end = l.until || l.at + HOLD_MS
  return [{ name: "Rate limit", used: 100, resetsAt: new Date(end).toISOString(), aside: true }]
}

// kept is res saying magpie is to leave the account's sign-in be.
function kept(res) {
  const headers = new Headers(res.headers)
  headers.delete("content-length")
  headers.delete("content-encoding")
  headers.set("X-Magpie-Sign-In", "kept")
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers })
}

// ---- speech to text -----------------------------------------------------------

// Grok Build's voice dictation sends audio to xAI's own speech-to-text,
// POST api.x.ai/v1/stt, signed as every other request of the CLI is. magpie's
// /v1/audio/transcriptions arrives here as OpenAI's multipart form; xAI's
// takes `file` last, an optional `language`, and no `model` of OpenAI's
// (the one it has is the default, and any other id is a 404).
const STT = "https://api.x.ai/v1/stt"
const STT_FORMATS = ["json", "text", "verbose_json"]

async function sttRequest(body, ctype) {
  let form
  try {
    form = await new Response(body, { headers: { "content-type": ctype } }).formData()
  } catch {
    return { error: "send the audio as multipart/form-data, as OpenAI's /v1/audio/transcriptions takes it: a file and a model" }
  }
  const file = form.get("file")
  if (!(file instanceof Blob)) return { error: "the form has no audio file" }
  const format = String(form.get("response_format") || "json")
  if (!STT_FORMATS.includes(format)) return { error: `Grok's speech to text answers json, text or verbose_json, not ${format}` }
  const out = new FormData()
  const language = form.get("language")
  if (typeof language === "string" && language) out.set("language", language)
  out.set("file", file, file.name || "audio")
  return { form: out, format }
}

// sttAnswer is xAI's answer in the shape OpenAI's takes for the format
// asked: its words are {text, start, end}, OpenAI's {word, start, end}.
async function sttAnswer(res, format) {
  let a
  try {
    a = await res.json()
  } catch {
    return new Response("Grok's speech to text answered something that isn't JSON", { status: 502 })
  }
  const text = typeof a?.text === "string" ? a.text : ""
  const headers = new Headers({ "X-Magpie-Sign-In": "kept" })
  if (format === "text") {
    headers.set("content-type", "text/plain; charset=utf-8")
    return new Response(text, { status: 200, headers })
  }
  headers.set("content-type", "application/json")
  if (format === "json") return new Response(JSON.stringify({ text }), { status: 200, headers })
  const words = Array.isArray(a.words) ? a.words.map((w) => ({ word: w.text, start: w.start, end: w.end })) : []
  return new Response(JSON.stringify({ task: "transcribe", language: a.language, duration: a.duration, text, words }), { status: 200, headers })
}

const failure = (status, message, extra = {}) =>
  new Response(JSON.stringify({ error: { message, type: status === 401 ? "authentication_error" : "invalid_request_error" } }), {
    status,
    headers: { "content-type": "application/json", ...extra },
  })

async function transcribe(auth, req, init) {
  const home = auth?.refresh
  if (req.url.includes("/audio/translations")) return failure(400, "Grok's speech to text transcribes; it doesn't translate")
  const raw = init?.body
  const body = typeof raw === "string" ? Buffer.from(raw) : raw
  const ask = body ? await sttRequest(body, req.headers.get("content-type") ?? "") : { error: "the request has no body" }
  if (ask.error) return failure(400, ask.error)
  let c = await token(home)
  const send = async (key) => {
    const headers = new Headers()
    await sign(headers, key, STT)
    return fetch(STT, { method: "POST", headers, body: ask.form, signal: init?.signal })
  }
  let res = await send(c.key)
  if (res.status === 401) {
    const said = (await res.text().catch(() => "")).slice(0, 300)
    try {
      c = await token(home, c.key, said)
    } catch (e) {
      note(home, res)
      return failure(e?.transient ? 503 : 401, `${e.message}${said ? `. Grok said: ${said}` : ""}`, { "X-Magpie-Sign-In": "kept", ...(e?.transient ? { "retry-after": String(RETRY_SECS) } : {}) })
    }
    res = await send(c.key)
  }
  note(home, res)
  if (res.ok) return sttAnswer(res, ask.format)
  const said = (await res.text().catch(() => "")).slice(0, 300)
  let msg = said
  try {
    const j = JSON.parse(said)
    msg = typeof j?.error === "string" ? j.error : (j?.error?.message ?? said)
  } catch {}
  return failure(res.status, `Grok's speech to text: ${msg || res.status}`, { "X-Magpie-Sign-In": "kept" })
}

// ---- the plugin ---------------------------------------------------------------

// A Responses stream that dies before its first byte is asked again, up
// to three times, before this answer is returned. A retry's 429 or 401
// is that answer: note sees it, and it is not folded into a 200. Once a
// byte has arrived, response.created and reasoning included, it is
// passed on at once. A later cut is not asked again and not rewritten.
// The stream just ends. magpie 0.1.3298 and newer closes a Responses
// stream that ends short as response.failed, with the stream's id,
// created_at and the next sequence_number (yetone/magpie 29bfd5dc8).
// The frame this plugin used to write had created_at and still no
// sequence_number, and Grok Build failed the turn on it. An upstream
// response.failed, error or response.incomplete is passed on unchanged.
// Cancelling stops the upstream read.
const STREAM_TRIES = 3
const CUT = /ECONNRESET|EPIPE|ETIMEDOUT|ECONNABORTED|socket connection was closed|connection lost|unexpected EOF|terminated|other side closed|UND_ERR|network connection|ECONNREFUSED/i

function eventStream(res) {
  const type = res?.headers?.get?.("content-type") || ""
  return res?.status === 200 && !!res?.body && /text\/event-stream/i.test(type)
}

// firstByte reads one chunk. A failure here is still before anything was
// sent, so the caller can ask again. The reader stays open when a chunk
// did arrive: the rest of the body follows it.
async function firstByte(body) {
  const reader = body.getReader()
  try {
    const { done, value } = await reader.read()
    if (done) return { kind: "end", reader }
    return { kind: "byte", value, reader }
  } catch (cause) {
    const reason = String(cause?.message || cause)
    try { await reader.cancel(cause) } catch {}
    return { kind: "cut", reason }
  }
}

function bare(res, stream) {
  const headers = new Headers(res.headers)
  headers.delete("content-length")
  headers.delete("content-encoding")
  return new Response(stream, { status: res.status, statusText: res.statusText, headers })
}

// passThrough sends the chunk already read, then one upstream chunk per
// pull. Nothing is buffered past that, and cancel stops the upstream read.
function passThrough(res, reader, first) {
  let lead = first
  let leadWaiting = true
  const stream = new ReadableStream({
    async pull(controller) {
      if (leadWaiting) {
        leadWaiting = false
        if (lead) controller.enqueue(lead)
        lead = undefined
        return
      }
      try {
        const { done, value } = await reader.read()
        if (done) {
          controller.close()
          return
        }
        controller.enqueue(value)
      } catch (cause) {
        const reason = String(cause?.message || cause)
        try { await reader.cancel(cause) } catch {}
        // cancel already closed this stream: nothing more to report
        if (controller.desiredSize === null) return
        console.warn(`[grok-auth] stream failed (${reason.slice(0, 160)})`)
        try { controller.close() } catch {}
      }
    },
    cancel(reason) {
      return reader.cancel(reason)
    },
  })
  return bare(res, stream)
}

function ended(res) {
  return bare(res, new ReadableStream({
    start(controller) { controller.close() },
  }))
}

async function cutRetry(res, again, { tries = STREAM_TRIES } = {}) {
  let current = res
  for (let attempt = 1; attempt <= tries; attempt++) {
    if (attempt > 1) {
      try {
        current = await again()
      } catch (cause) {
        const said = String(cause?.message || cause)
        console.warn(`[grok-auth] retry ${attempt}/${tries} did not start: ${said.slice(0, 160)}`)
        if (!CUT.test(said) || attempt === tries) return ended(res)
        continue
      }
    }
    if (!eventStream(current)) return current
    const read = await firstByte(current.body)
    if (read.kind === "byte") return passThrough(current, read.reader, read.value)
    if (read.kind === "end") {
      try { await read.reader.cancel() } catch {}
      return ended(current)
    }
    const reason = read.reason
    if (!CUT.test(reason) || attempt === tries) {
      console.warn(`[grok-auth] stream failed (${reason.slice(0, 160)})`)
      return ended(current)
    }
    console.warn(`[grok-auth] stream cut before any byte (${reason.slice(0, 140)}); retry ${attempt + 1}/${tries}`)
  }
  return ended(current)
}

export const GrokAuthPlugin = async ({ client, magpie }) => {
  const remember = async (auth, c) => {
    if (auth.access === c.key && auth.expires === c.expires) return
    try {
      await client.auth.set({ path: { id: PROVIDER }, body: { ...auth, access: c.key, expires: c.expires, accountId: c.who || auth.accountId } })
    } catch {}
  }

  return {
    config: async (cfg) => {
      cfg.provider ??= {}
      cfg.provider[PROVIDER] ??= {
        name: "Grok (SuperGrok)",
        npm: "@ai-sdk/openai",
        api: BASE,
        models: DEFAULT_MODELS,
      }
    },

    auth: {
      provider: PROVIDER,
      options: [
        {
          key: "x_search",
          label: "Native X search",
          description: "Offers X search to Grok when tools are automatic. Keeps existing search filters and explicit tool choices. Grok decides whether to search.",
        },
      ],
      // magpie renews the sign-in LEAD_MS before its end, once for the
      // account, before its requests, models and usage ask for it: the CLI
      // renews it in its home, as before a request, and what it gives is
      // read back. The check before each request stays for OpenCode, which
      // doesn't call this.
      refreshLead: LEAD_MS,
      async refresh(auth) {
        const home = auth?.refresh
        if (auth?.type !== "oauth" || !home) return undefined
        let c = await credential(home)
        // renewed already (by the CLI, or before a request), the store not
        // yet saying so
        const renewed = c && c.key !== auth.access && c.expires - Date.now() >= LEAD_MS
        const exe = executable()
        let r
        if (!renewed && exe) {
          r = await renew(exe, home)
          c = await credential(home)
        }
        // the CLI holds no sign-in there any more (`grok logout`): one
        // has to be made again
        if (!c) throw Object.assign(new Error(notSignedIn(home)), { signIn: "expired" })
        // the CLI couldn't renew it: tried again later
        if (exe && c.expires && c.expires <= Date.now()) throw unrenewed(home, r)
        if (c.key === auth.access && c.expires === auth.expires) return undefined
        // magpie saves what this gives
        const out = { access: c.key, expires: c.expires }
        if (c.email && c.email !== auth.accountId) out.accountId = c.email
        return out
      },
      async loader(getAuth) {
        const auth = await getAuth()
        if (!auth || auth.type !== "oauth") return {}
        return {
          baseURL: BASE,
          apiKey: "grok",
          async fetch(input, init) {
            const auth = await getAuth()
            const home = auth?.refresh
            if (!home) throw new Error("Grok is not signed in; run `grok login`")
            const req = new Request(input, init)
            if (new URL(req.url).pathname.match(/\/audio\/(transcriptions|translations)$/)) return transcribe(auth, req, init)
            const search = new URL(req.url).pathname.endsWith("/responses") && magpie?.option?.(PROVIDER, "x_search") === true
            let body = rewrite(bodyText(init?.body), search)
            let parsed = {}
            if (typeof body === "string") {
              try {
                parsed = JSON.parse(body) ?? {}
              } catch {}
            }
            let c = await token(home)
            await remember(auth, c)
            const headers = new Headers(req.headers)
            const asked = modelOf(parsed.model)
            if (asked.model) {
              headers.set("x-grok-model-override", asked.model)
              if (asked.window && typeof body === "string") {
                parsed.model = asked.model
                body = JSON.stringify(parsed)
              }
            }
            if (asked.window) headers.set("x-grok-context-window", String(asked.window))
            if (typeof parsed.prompt_cache_key === "string" && parsed.prompt_cache_key) headers.set("x-grok-conv-id", parsed.prompt_cache_key)
            // Grok Build asks the proxy to watch every Responses stream for a
            // model stuck repeating itself: without these the proxy cuts a
            // loop only after ~4K tokens, and a looser one (a fence or a line
            // over and over) runs to max_output_tokens (yetone/magpie#3594).
            // The values are Grok Build 1.0.67's (doom_loop_recovery's
            // max_threshold is the 64).
            if (new URL(req.url).pathname.endsWith("/responses")) {
              for (const [k, v] of LOOP_CHECKS) if (!headers.has(k)) headers.set(k, v)
            }
            headers.delete("content-length")
            let at = 0 // when the last request went out, signed
            const send = async (key) => {
              await sign(headers, key, req.url)
              at = Date.now()
              return fetch(req.url, { ...init, method: req.method, headers, body })
            }
            // Grok's answer goes on as it came, the account kept, as the
            // built-in never marked a Grok account lapsed nor cleared one.
            // A token Grok turns away before its time (it can, ahead of
            // expires_at) is renewed by Grok Build and the request sent once
            // more; one Grok Build couldn't renew is a 401 saying so, and
            // what helps.
            //
            // A 401 that wasn't Grok's judgement of the token, on one Grok
            // Build left as it was and still good, is a refusal that passes
            // by itself (plugins#818): a 503 saying so, with Retry-After,
            // so magpie rests the account a moment and asks the next, and
            // never says to sign in again. How long Grok took to answer is
            // in the words: the wait is Grok's, not the plugin's.
            let res = await send(c.key)
            if (res.status === 401 && (typeof body === "string" || body == null)) {
              const took = Date.now() - at
              const said = (await res.text().catch(() => "")).slice(0, 300)
              try {
                c = await token(home, c.key, said)
              } catch (e) {
                note(home, res)
                const after = took >= 1000 ? ` after ${Math.round(took / 1000)}s` : ""
                if (e?.transient) {
                  return kept(
                    new Response(JSON.stringify({ error: { message: `${e.message}. Grok answered 401${after}`, type: "server_error", code: "auth_refused_transient" } }), {
                      status: 503,
                      headers: { "content-type": "application/json", "retry-after": String(RETRY_SECS) },
                    }),
                  )
                }
                return kept(
                  new Response(JSON.stringify({ error: { message: `${e.message}${said ? `. Grok said${after}: ${said}` : ""}`, type: "authentication_error", code: "sign_in_unrenewed" } }), {
                    status: 401,
                    statusText: res.statusText,
                    headers: { "content-type": "application/json" },
                  }),
                )
              }
              await remember(auth, c)
              res = await send(c.key)
            }
            note(home, res)
            return kept(await cutRetry(res, async () => {
              const next = await send(c.key)
              note(home, next)
              return next
            }))
          },
        }
      },
      // magpie's multi-file/paste import; OpenCode uses the single-account method.
      importFrom: IMPORT_FROM,
      import: importAccounts,
      methods: [
        {
          type: "oauth",
          label: "Sign in with Grok Build (device code)",
          authorize: signIn,
        },
        {
          type: "oauth",
          label: "Use Grok Build's current sign-in",
          authorize: current,
        },
        {
          type: "oauth",
          label: "Import CPA / sub2api Grok account JSON",
          prompts: [
            {
              type: "text",
              key: "path",
              message: "Path to a CPA or sub2api Grok OAuth account JSON file, or paste JSON. Stop using it in the source client; its refresh token rotates.",
              placeholder: "~/.cli-proxy-api/xai-<email>.json or {\"platform\":\"grok\",...}",
              validate: (v) => (String(v ?? "").trim() ? undefined : "Enter a Grok account JSON file path or paste JSON"),
            },
          ],
          authorize: importCPA,
        },
      ],
      // magpie's: how much of the subscription's allowance is gone; each
      // read keeps the sign-in (signIn), as the built-in's marked no
      // account lapsed nor cleared one
      async usage(getAuth) {
        const auth = await getAuth()
        let c
        try {
          if (!auth || auth.type !== "oauth" || !auth.refresh) throw new Error("Grok is not signed in; run `grok login`")
          c = await token(auth.refresh)
        } catch (e) {
          return { error: e.message, windows: [], signIn: "kept" }
        }
        await remember(auth, c)
        let u = await usage(c.key)
        // a token turned away is renewed once, as a request's is
        if (u.status === 401) {
          try {
            c = await token(auth.refresh, c.key, u.said)
          } catch (e) {
            return { error: e.message, windows: [], signIn: "kept" }
          }
          await remember(auth, c)
          u = await usage(c.key)
        }
        delete u.status
        delete u.said
        if (!u.error) u.windows = [...rateWindow(auth.refresh), ...u.windows]
        return { ...u, signIn: "kept" }
      },
    },

    provider: {
      id: PROVIDER,
      async models(provider, { auth } = {}) {
        const have = provider?.models ?? {}
        if (!auth || auth.type !== "oauth" || !auth.refresh) return have
        // a list Grok couldn't give is a failure, not the few configured:
        // magpie keeps the list it had
        let c = await token(auth.refresh)
        let list
        try {
          list = await listModels(c.key)
        } catch (e) {
          if (e?.status !== 401) throw e
          // turned away before its time: renewed once, as a request's is
          c = await token(auth.refresh, c.key, e.said)
          list = await listModels(c.key).catch((e) => {
            throw e?.status === 401 ? new Error(dead(auth.refresh)) : e
          })
        }
        const base = have["grok-4.7"] ?? Object.values(have)[0] ?? {}
        const out = {}
        for (const m of list) {
          const was = have[m.id] ?? have[m.apiId] ?? base
          out[m.id] = {
            ...was,
            id: m.id,
            providerID: provider.id,
            name: m.name,
            // the id as offered, window and all: magpie and the AI SDK send
            // api.id as the body's model, and fetch reads the window from it
            // (modelOf) before Grok sees the plain model
            api: { ...(was.api ?? {}), id: m.id, url: BASE, npm: "@ai-sdk/openai" },
            limit: { ...(was.limit ?? {}), context: m.context || was.limit?.context || 0, output: was.limit?.output ?? 0 },
            capabilities: {
              ...(was.capabilities ?? {}),
              reasoning: m.efforts.length > 0 || !!was.capabilities?.reasoning,
              attachment: true,
              toolcall: true,
              input: { ...(was.capabilities?.input ?? {}), text: true, image: true },
            },
            variants: Object.fromEntries(m.efforts.map((e) => [e, { reasoningEffort: e }])),
          }
        }
        return out
      },
    },
  }
}

// for tests
export const _internal = { sttRequest, sttAnswer, rewrite, objectRoot, bodyText, limited, HOLD_MS, windowsOf, modelOf, waits }
