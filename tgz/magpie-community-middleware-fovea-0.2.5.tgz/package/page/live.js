globalThis.FoveaLive = null;
